package bankManagementSystem;

import java.sql.*;
import java.util.Scanner;

public class Bank {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/BankDB";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "nandy131205@#";  // Replace with your MySQL password
    private Connection conn;
    private Scanner scanner = new Scanner(System.in);

    // Constructor to establish connection
    public Bank() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
            System.out.println("Connected to the database.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Account Creation
    public void createAccount(String name, double initialDeposit) {
        String query = "INSERT INTO Accounts (name, balance) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, name);
            stmt.setDouble(2, initialDeposit);
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int accountId = rs.getInt(1);
                System.out.println("Account created successfully. Your Account ID is: " + accountId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Login Method
    public int login(String name) {
        String query = "SELECT account_id FROM Accounts WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int accountId = rs.getInt("account_id");
                System.out.println("Login successful. Your Account ID is: " + accountId);
                return accountId;
            } else {
                System.out.println("Account not found.");
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    // Deposit Method
    public void deposit(int accountId, double amount) {
        if (amount <= 0) {
            System.out.println("Deposit amount must be positive.");
            return;
        }
        String query = "UPDATE Accounts SET balance = balance + ? WHERE account_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDouble(1, amount);
            stmt.setInt(2, accountId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Deposit successful.");
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Withdrawal Method
    public void withdraw(int accountId, double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal amount must be positive.");
            return;
        }
        String checkBalanceQuery = "SELECT balance FROM Accounts WHERE account_id = ?";
        String updateQuery = "UPDATE Accounts SET balance = balance - ? WHERE account_id = ?";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkBalanceQuery);
             PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {

            checkStmt.setInt(1, accountId);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("balance");
                if (currentBalance >= amount) {
                    updateStmt.setDouble(1, amount);
                    updateStmt.setInt(2, accountId);
                    updateStmt.executeUpdate();
                    System.out.println("Withdrawal successful.");
                } else {
                    System.out.println("Insufficient balance.");
                }
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Display Balance
    public void displayBalance(int accountId) {
        String query = "SELECT balance FROM Accounts WHERE account_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, accountId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                System.out.println("Account ID: " + accountId + ", Balance: $" + balance);
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete Account
    public void deleteAccount(int accountId) {
        String query = "DELETE FROM Accounts WHERE account_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, accountId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Account deleted successfully.");
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Close Connection
    public void close() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Disconnected from the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Main menu to interact with the system
    public void showMenu() {
        int choice;
        int loggedInAccountId = -1;
        do {
            System.out.println("\n--- Bank Management System ---");
            System.out.println("1. Create Account");
            System.out.println("2. Login");
            System.out.println("3. Deposit");
            System.out.println("4. Withdraw");
            System.out.println("5. Display Balance");
            System.out.println("6. Delete Account");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.next();
                    System.out.print("Enter initial deposit: ");
                    double initialDeposit = scanner.nextDouble();
                    createAccount(name, initialDeposit);
                    break;
                case 2:
                    System.out.print("Enter name: ");
                    String loginName = scanner.next();
                    loggedInAccountId = login(loginName);
                    break;
                case 3:
                    if (loggedInAccountId != -1) {
                        System.out.print("Enter deposit amount: ");
                        double depositAmount = scanner.nextDouble();
                        deposit(loggedInAccountId, depositAmount);
                    } else {
                        System.out.println("Please login first.");
                    }
                    break;
                case 4:
                    if (loggedInAccountId != -1) {
                        System.out.print("Enter withdrawal amount: ");
                        double withdrawAmount = scanner.nextDouble();
                        withdraw(loggedInAccountId, withdrawAmount);
                    } else {
                        System.out.println("Please login first.");
                    }
                    break;
                case 5:
                    if (loggedInAccountId != -1) {
                        displayBalance(loggedInAccountId);
                    } else {
                        System.out.println("Please login first.");
                    }
                    break;
                case 6:
                    if (loggedInAccountId != -1) {
                        deleteAccount(loggedInAccountId);
                        loggedInAccountId = -1; // logout after account deletion
                    } else {
                        System.out.println("Please login first.");
                    }
                    break;
                case 7:
                    System.out.println("Exiting the system.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 7);
        close();
    }

    public static void main(String[] args) {
        Bank bank = new Bank();
        bank.showMenu();
    }
}