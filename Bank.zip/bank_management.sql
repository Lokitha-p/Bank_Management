-- Ensure the database exists
CREATE DATABASE IF NOT EXISTS BankingApp;
USE BankingApp;

-- Drop tables in the correct order to avoid foreign key conflicts
DROP TABLE IF EXISTS Deposit;
DROP TABLE IF EXISTS Withdrawal;
DROP TABLE IF EXISTS Balance;
DROP TABLE IF EXISTS Statement;
DROP TABLE IF EXISTS Account;

-- Recreate tables
CREATE TABLE Account (
    account_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    account_type VARCHAR(50),
    balance DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Deposit (
    deposit_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT,
    amount DECIMAL(10, 2),
    deposit_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deposit_method VARCHAR(50),
    FOREIGN KEY (account_id) REFERENCES Account(account_id) ON DELETE CASCADE
);

CREATE TABLE Withdrawal (
    withdrawal_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT,
    amount DECIMAL(10, 2),
    withdrawal_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    withdrawal_method VARCHAR(50),
    FOREIGN KEY (account_id) REFERENCES Account(account_id) ON DELETE CASCADE
);

CREATE TABLE Balance (
    balance_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT,
    balance DECIMAL(15, 2),
    FOREIGN KEY (account_id) REFERENCES Account(account_id) ON DELETE CASCADE
);

CREATE TABLE Statement (
    statement_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT,
    opening_balance DECIMAL(15, 2),
    closing_balance DECIMAL(15, 2),
    statement_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES Account(account_id) ON DELETE CASCADE
);
